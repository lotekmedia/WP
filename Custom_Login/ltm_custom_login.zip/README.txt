=== Plugin Name ===
Contributors: lotekmedia
Tags: test, custom login
Requires at least: 3.3.1
Tested up to: 3.5.1
Stable tag: trunk

This is just my first attempt at writing a plugin.  Do not use this as a template.

== Description ==

As I said, I'm just writing my first plugin and want to see the process for releasing it.
Do NOT use this as a template.  Feel free to update the code for your local site and update your login page.

You will see two functions:
ltm_custom_login_url and ltm_custom_header_title

The ltm_custom_login_url is a link in the header image on the login page.
The ltm_custom_header_title updates the image to use the wheel if you are using the twenty-eleven theme.

== Installation ==

1. Upload `test_custom_login.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Why does this have everything hard-coded? =

Because I'm just trying to write a plug-in and see how publishing it works.

= Can I modify this for my site? =

Of course!  I'm surprised you are even reading this far into my test documentation

== Changelog ==

= 0.0.1a =
* My initial plug-in release.
