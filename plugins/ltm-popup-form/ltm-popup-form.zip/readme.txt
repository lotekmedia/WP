=== LTM Popup Form ===
Contributors: john mann
Plugin URI: http://github.com/lotekmedia/WordPress/ltm-popup-form/
Author URI: http://johnmann.org
Tags: popup, form
Requires at least: 3.4
Tested up to: 3.9
Stable tag: 1.0
License:

  Copyright 2014 LoTekMedia (john@lotekmedia.com)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License, version 2, as 
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Plugin to allow users to create and add a popup form easily on the website. 

== Description ==
This popup form allows user to add a popup form easily on their blog for high visibility.
That popup form will send emails to site admin, or configured address.

== Installation ==
1. From Plugin Upload 'ltm-popup-form.zip'
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Can I change the position of the popup? =

Of course, you can update the CSS easily and override whatever position you want for the popup button or the form itself.
I am working on additional configuration options currently.


== Changelog ==

= 1.0 =
* My initial release of a popupp form plugin
* Customization for localization, button color, background color, and email


== Upgrade Notice ==

= 1.0 =
First version
